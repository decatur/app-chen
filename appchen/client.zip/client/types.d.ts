interface MyProps {
    start: String;
    end: String;
}

interface App {

}
